//Program without exception handling
package com.tnsif.exceptionhandling;
public class WithoutExceptionHandling {

	public static void main(String[] args) {
		System.out.println("the program continues....");
		int data=100/0;
	}
	
}
