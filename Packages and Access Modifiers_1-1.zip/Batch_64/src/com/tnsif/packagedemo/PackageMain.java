package com.tnsif.packagedemo;

import com.tnsif.packagesandaccessmodifiers.PackageExample;

public class PackageMain {

	public static void main(String[] args) {

		PackageExample pe = new PackageExample();
		pe.display();

	}

}
